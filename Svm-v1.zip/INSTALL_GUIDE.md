# SVM Panel - Complete Installation Guide

## Quick Start (Recommended)

### Step 1: Download and Extract
```bash
# Download the package
wget <download-link>/svm-panel.tar.gz

# Extract
tar -xzf svm-panel.tar.gz
cd svm-panel
```

### Step 2: Run Installation Script
```bash
# Make sure you have sudo access
sudo ./install.sh
```

### Step 3: Start the Panel
```bash
# Activate virtual environment
source venv/bin/activate

# Start SVM Panel
python3 app.py
```

### Step 4: Access the Panel
Open your web browser and navigate to:
```
http://localhost:3000
```

**Default Login:**
- Username: `admin`
- Password: `admin`

⚠️ **Change the admin password immediately after first login!**

---

## Detailed Installation Steps

### Prerequisites Check

Before installing, ensure your system meets these requirements:

```bash
# Check Ubuntu version (should be 22.04 or newer)
lsb_release -a

# Check available RAM (should be at least 4GB)
free -h

# Check available disk space (should be at least 20GB free)
df -h

# Check if you have sudo access
sudo whoami
```

### Manual Installation (If Script Fails)

#### 1. Update System
```bash
sudo apt update
sudo apt upgrade -y
```

#### 2. Install LXC/LXD
```bash
# Install LXC
sudo apt install lxc lxc-utils bridge-utils uidmap -y

# Install snapd
sudo apt install snapd -y
sudo systemctl enable --now snapd.socket

# Install LXD via snap
sudo snap install lxd
```

#### 3. Configure User Permissions
```bash
# Add your user to lxd group
sudo usermod -aG lxd $USER

# Apply group membership
newgrp lxd

# Verify
groups
```

#### 4. Initialize LXD
```bash
sudo lxd init
```

**Answer the prompts as follows:**
```
Would you like to use LXD clustering? (yes/no) [default=no]: no
Do you want to configure a new storage pool? (yes/no) [default=yes]: yes
Name of the new storage pool [default=default]: default
Name of the storage backend to use (dir, lvm, zfs, btrfs, ceph) [default=zfs]: dir
Would you like to connect to a MAAS server? (yes/no) [default=no]: no
Would you like to create a new local network bridge? (yes/no) [default=yes]: yes
What should the new bridge be called? [default=lxdbr0]: lxdbr0
What IPv4 address should be used? [default=auto]: auto
What IPv6 address should be used? [default=auto]: auto
Would you like the LXD server to be available over the network? (yes/no) [default=no]: no
Would you like stale cached images to be updated automatically? (yes/no) [default=yes]: yes
Would you like a YAML "lxd init" preseed to be printed? (yes/no) [default=no]: no
```

#### 5. Install Python and Dependencies
```bash
# Install Python 3
sudo apt install python3 python3-pip python3-venv -y

# Navigate to svm-panel directory
cd /opt/svm-panel  # or wherever you extracted it

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install Python packages
pip install --upgrade pip
pip install -r requirements.txt
```

#### 6. Verify LXC Installation
```bash
# Test LXC
lxc list

# If you see a list (even if empty), LXC is working!
```

---

## Running SVM Panel

### Option 1: Manual Start (Development)
```bash
cd /opt/svm-panel
source venv/bin/activate
python3 app.py
```

### Option 2: Using Start Script
```bash
cd /opt/svm-panel
./start.sh
```

### Option 3: Systemd Service (Production)
```bash
# Copy service file
sudo cp svm-panel.service /etc/systemd/system/

# Reload systemd
sudo systemctl daemon-reload

# Start service
sudo systemctl start svm-panel

# Enable on boot
sudo systemctl enable svm-panel

# Check status
sudo systemctl status svm-panel

# View logs
sudo journalctl -u svm-panel -f
```

---

## Post-Installation Configuration

### 1. Change Admin Password
1. Login with `admin/admin`
2. Go to **Profile**
3. Change password
4. Save

### 2. Configure Firewall (Optional but Recommended)
```bash
# Install UFW if not installed
sudo apt install ufw -y

# Allow SSH (IMPORTANT: Don't lock yourself out!)
sudo ufw allow 22/tcp

# Allow SVM Panel port
sudo ufw allow 3000/tcp

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status
```

### 3. Setup Nginx Reverse Proxy (Optional for Production)
```bash
# Install Nginx
sudo apt install nginx -y

# Create config file
sudo nano /etc/nginx/sites-available/svm-panel
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com;  # Change this

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/svm-panel /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

### 4. Setup SSL with Let's Encrypt (Optional)
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx -y

# Get certificate
sudo certbot --nginx -d your-domain.com

# Auto-renewal is already configured
```

---

## Usage Guide

### Creating Your First VPS

#### As Admin:
1. Login to SVM Panel
2. Go to **Admin Panel** → **Manage VPS**
3. Fill in the form:
   - **Username**: Enter the username who will own this VPS
   - **RAM**: Enter RAM in GB (e.g., 4)
   - **CPU**: Enter number of CPU cores (e.g., 2)
   - **Disk**: Enter disk space in GB (e.g., 50)
4. Click **Create VPS**
5. Wait for creation to complete (usually 30-60 seconds)

### Managing VPS

#### Start/Stop VPS:
1. Go to **Dashboard**
2. Click **Manage** on your VPS
3. Use control buttons:
   - **Start**: Boot the VPS
   - **Stop**: Shutdown the VPS
   - **Restart**: Reboot the VPS

#### Access VPS via SSH:
1. Go to **Dashboard** → **Manage** your VPS
2. Click **SSH Access** button
3. Copy the generated tmate command
4. Open your terminal and paste the command
5. Press Enter to connect

### Admin Tasks

#### Create a New User:
1. **Admin Panel** → **Manage Users**
2. Click **Add New User**
3. Fill in details:
   - Username
   - Email
   - Password
   - Role (User or Admin)
4. Click **Add User**

#### Suspend a VPS:
1. **Admin Panel** → **Manage VPS**
2. Find the VPS
3. Click **Suspend** button
4. Confirm action

#### View System Statistics:
1. Go to **Admin Panel**
2. View overview cards:
   - Total Users
   - Total VPS
   - Running VPS
   - CPU Usage
3. Check resource summaries

---

## Troubleshooting

### Problem: "lxc command not found"
**Solution:**
```bash
# Check if LXD is installed
snap list | grep lxd

# If not found, install it
sudo snap install lxd

# Initialize it
sudo lxd init
```

### Problem: "Permission denied" when running lxc commands
**Solution:**
```bash
# Add yourself to lxd group
sudo usermod -aG lxd $USER

# You need to log out and log back in, or run:
newgrp lxd

# Verify
groups
```

### Problem: Port 3000 already in use
**Solution 1:** Kill the process using port 3000
```bash
sudo lsof -i :3000
sudo kill -9 <PID>
```

**Solution 2:** Change the port in `app.py`
```python
# At the bottom of app.py, change:
app.run(host='0.0.0.0', port=5000, debug=True)  # Change 3000 to 5000
```

### Problem: VPS won't start
**Check Container Status:**
```bash
lxc info <container-name>
```

**Check Logs:**
```bash
lxc info <container-name> --show-log
```

**Force Start:**
```bash
lxc start <container-name> --force
```

### Problem: Can't login to panel
**Reset Admin Password:**
```bash
cd /opt/svm-panel
source venv/bin/activate
python3
```

Then in Python:
```python
import json
from werkzeug.security import generate_password_hash

# Load users
with open('users.json', 'r') as f:
    users = json.load(f)

# Reset admin password
users['admin']['password'] = generate_password_hash('newpassword')

# Save
with open('users.json', 'w') as f:
    json.dump(users, f, indent=4)

print("Password reset to: newpassword")
```

### Problem: High CPU usage
**Check Running Containers:**
```bash
lxc list
```

**Stop All Containers:**
```bash
lxc stop --all --force
```

**Monitor Host CPU:**
```bash
top
htop  # if installed
```

---

## Backup and Restore

### Backup Important Data
```bash
# Backup configuration files
cd /opt/svm-panel
tar -czf svm-panel-backup-$(date +%Y%m%d).tar.gz users.json vps_data.json settings.json

# Move to safe location
mv svm-panel-backup-*.tar.gz /home/backup/
```

### Backup VPS Containers
```bash
# Snapshot a container
lxc snapshot <container-name> backup-$(date +%Y%m%d)

# Export container
lxc export <container-name> /home/backup/<container-name>.tar.gz
```

### Restore from Backup
```bash
# Restore configuration files
cd /opt/svm-panel
tar -xzf /home/backup/svm-panel-backup-YYYYMMDD.tar.gz

# Import container
lxc import /home/backup/<container-name>.tar.gz
```

---

## Monitoring and Maintenance

### Check Service Status
```bash
sudo systemctl status svm-panel
```

### View Application Logs
```bash
# If running as service
sudo journalctl -u svm-panel -f

# If running manually
tail -f /opt/svm-panel/app.log  # if you configure logging
```

### Update SVM Panel
```bash
# Stop the service
sudo systemctl stop svm-panel

# Backup current installation
cd /opt
sudo tar -czf svm-panel-old.tar.gz svm-panel/

# Extract new version
# (download new version first)
sudo tar -xzf svm-panel-new.tar.gz

# Start service
sudo systemctl start svm-panel
```

---

## Security Best Practices

1. **Change Default Credentials** immediately
2. **Use Strong Passwords** for all accounts
3. **Enable Firewall** (UFW)
4. **Use SSH Keys** instead of passwords for server access
5. **Regular Updates**:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```
6. **Monitor Logs** regularly
7. **Backup Data** frequently
8. **Use SSL/HTTPS** in production
9. **Limit Admin Access** - don't give admin role unnecessarily
10. **Regular Security Audits**

---

## Advanced Configuration

### Change Default Port
Edit `app.py`, line ~24:
```python
app.run(host='0.0.0.0', port=8080, debug=False)  # Change port here
```

### Modify CPU/RAM Thresholds
Edit `app.py`, lines ~15-17:
```python
CPU_THRESHOLD = 80  # Change from 90 to 80
RAM_THRESHOLD = 80  # Change from 90 to 80
```

### Change Default Storage Pool
Edit `app.py`, line ~14:
```python
DEFAULT_STORAGE_POOL = 'mypool'  # Change from 'default'
```

---

## Getting Help

If you encounter issues:

1. Check this installation guide
2. Review troubleshooting section
3. Check system logs
4. Verify LXC/LXD is working: `lxc list`
5. Contact your system administrator

---

## Uninstallation

To completely remove SVM Panel:

```bash
# Stop service (if installed)
sudo systemctl stop svm-panel
sudo systemctl disable svm-panel
sudo rm /etc/systemd/system/svm-panel.service

# Remove all containers
lxc delete --force $(lxc list --format csv -c n)

# Remove application
sudo rm -rf /opt/svm-panel

# Remove LXD (optional)
sudo snap remove lxd

# Remove LXC (optional)
sudo apt remove lxc lxc-utils -y
```

---

**Congratulations! Your SVM Panel is now installed and ready to use!** 🎉
