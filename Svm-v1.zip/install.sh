#!/bin/bash

echo "========================================="
echo "SVM Panel Installation Script"
echo "========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (use sudo)"
    exit 1
fi

echo "[1/6] Updating system packages..."
apt update && apt upgrade -y

echo ""
echo "[2/6] Installing LXC/LXD..."
apt install lxc lxc-utils -y
apt install snapd -y
systemctl enable --now snapd.socket
snap install lxd

echo ""
echo "[3/6] Setting up LXD..."
# Add current user to lxd group
CURRENT_USER=$(logname)
usermod -aG lxd $CURRENT_USER

echo ""
echo "[4/6] Installing Python dependencies..."
apt install python3 python3-pip python3-venv -y

echo ""
echo "[5/6] Setting up virtual environment..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "[6/6] Initializing LXD (will prompt for configuration)..."
echo "Press ENTER to accept defaults for all questions"
lxd init

echo ""
echo "========================================="
echo "Installation Complete!"
echo "========================================="
echo ""
echo "To start SVM Panel:"
echo "  1. Run: source venv/bin/activate"
echo "  2. Run: python3 app.py"
echo "  3. Open browser: http://localhost:3000"
echo ""
echo "Default admin credentials:"
echo "  Username: admin"
echo "  Password: admin"
echo ""
echo "⚠️  IMPORTANT: Change the admin password after first login!"
echo ""
echo "Note: You may need to log out and log back in for"
echo "      LXD group membership to take effect."
echo "========================================="
