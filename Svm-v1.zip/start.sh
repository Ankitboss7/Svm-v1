#!/bin/bash

echo "Starting SVM Panel..."

# Activate virtual environment
source venv/bin/activate

# Start the application
python3 app.py
