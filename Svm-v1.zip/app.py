#!/usr/bin/env python3
import os
import json
import time
import shlex
import asyncio
import threading
import subprocess
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'svm-panel-secret-key-change-this-in-production'
app.config['PERMANENT_SESSION_LIFETIME'] = 3600

# Configuration
DEFAULT_STORAGE_POOL = 'default'
CPU_THRESHOLD = 90
RAM_THRESHOLD = 90
CHECK_INTERVAL = 600

# Data files
USERS_FILE = 'users.json'
VPS_FILE = 'vps_data.json'
SETTINGS_FILE = 'settings.json'

# Global monitoring flag
cpu_monitor_active = True

# Helper functions for data management
def load_json(filename, default=None):
    try:
        with open(filename, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default if default is not None else {}

def save_json(filename, data):
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

def load_users():
    users = load_json(USERS_FILE, {})
    # Create default admin if no users exist
    if not users:
        users['admin'] = {
            'username': 'admin',
            'email': 'admin@svmpanel.local',
            'password': generate_password_hash('admin'),
            'role': 'admin',
            'created_at': datetime.now().isoformat()
        }
        save_json(USERS_FILE, users)
    return users

def load_vps():
    return load_json(VPS_FILE, {})

def load_settings():
    settings = load_json(SETTINGS_FILE, {
        'panel_name': 'SVM Panel',
        'announcement': 'Welcome To SVM PANEL',
        'background_image': '',
        'theme': 'dark'
    })
    return settings

def save_users(users):
    save_json(USERS_FILE, users)

def save_vps(vps_data):
    save_json(VPS_FILE, vps_data)

def save_settings(settings):
    save_json(SETTINGS_FILE, settings)

# LXC command execution
async def execute_lxc(command, timeout=120):
    try:
        cmd = shlex.split(command)
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        
        if proc.returncode != 0:
            error = stderr.decode().strip() if stderr else "Command failed"
            raise Exception(error)
        
        return stdout.decode().strip() if stdout else True
    except asyncio.TimeoutError:
        raise Exception(f"Command timed out after {timeout} seconds")
    except Exception as e:
        raise

def execute_lxc_sync(command, timeout=120):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(execute_lxc(command, timeout))
    finally:
        loop.close()

# VPS stat functions
def get_container_status(container_name):
    try:
        result = subprocess.run(['lxc', 'info', container_name], 
                              capture_output=True, text=True, timeout=10)
        for line in result.stdout.splitlines():
            if line.startswith("Status: "):
                return line.split(": ", 1)[1].strip()
        return "Unknown"
    except:
        return "Unknown"

def get_container_cpu(container_name):
    try:
        result = subprocess.run(['lxc', 'exec', container_name, '--', 'top', '-bn1'],
                              capture_output=True, text=True, timeout=10)
        for line in result.stdout.splitlines():
            if '%Cpu(s):' in line:
                words = line.split()
                for i, word in enumerate(words):
                    if word == 'id,':
                        idle = float(words[i-1].rstrip(','))
                        return f"{100.0 - idle:.1f}%"
        return "0.0%"
    except:
        return "N/A"

def get_container_memory(container_name):
    try:
        result = subprocess.run(['lxc', 'exec', container_name, '--', 'free', '-m'],
                              capture_output=True, text=True, timeout=10)
        lines = result.stdout.splitlines()
        if len(lines) > 1:
            parts = lines[1].split()
            total = int(parts[1])
            used = int(parts[2])
            pct = (used / total * 100) if total > 0 else 0
            return f"{used}/{total}MB ({pct:.1f}%)"
        return "N/A"
    except:
        return "N/A"

def get_container_disk(container_name):
    try:
        result = subprocess.run(['lxc', 'exec', container_name, '--', 'df', '-h', '/'],
                              capture_output=True, text=True, timeout=10)
        lines = result.stdout.splitlines()
        for line in lines:
            if '/dev/' in line and ' /' in line:
                parts = line.split()
                if len(parts) >= 5:
                    return f"{parts[2]}/{parts[1]} ({parts[4]})"
        return "N/A"
    except:
        return "N/A"

def get_cpu_usage():
    try:
        result = subprocess.run(['top', '-bn1'], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if '%Cpu(s):' in line:
                words = line.split()
                for i, word in enumerate(words):
                    if word == 'id,':
                        idle = float(words[i-1].rstrip(','))
                        return 100.0 - idle
        return 0.0
    except:
        return 0.0

def get_uptime():
    try:
        result = subprocess.run(['uptime'], capture_output=True, text=True)
        return result.stdout.strip()
    except:
        return "Unknown"

# CPU monitoring thread
def cpu_monitor():
    global cpu_monitor_active
    while cpu_monitor_active:
        try:
            cpu_usage = get_cpu_usage()
            if cpu_usage > CPU_THRESHOLD:
                subprocess.run(['lxc', 'stop', '--all', '--force'], check=True)
                vps_data = load_vps()
                for user_id, vps_list in vps_data.items():
                    for vps in vps_list:
                        if vps.get('status') == 'running':
                            vps['status'] = 'stopped'
                save_vps(vps_data)
            time.sleep(60)
        except:
            time.sleep(60)

# Start monitoring
monitor_thread = threading.Thread(target=cpu_monitor, daemon=True)
monitor_thread.start()

# Authentication decorators
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            flash('Please login first', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            flash('Please login first', 'error')
            return redirect(url_for('login'))
        users = load_users()
        if users.get(session['username'], {}).get('role') != 'admin':
            flash('Admin access required', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

# Routes
@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        users = load_users()
        user = users.get(username)
        
        if user and check_password_hash(user['password'], password):
            session['username'] = username
            session['role'] = user['role']
            flash(f'Welcome back, {username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    settings = load_settings()
    return render_template('login.html', settings=settings)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return redirect(url_for('register'))
        
        users = load_users()
        
        if username in users:
            flash('Username already exists', 'error')
            return redirect(url_for('register'))
        
        users[username] = {
            'username': username,
            'email': email,
            'password': generate_password_hash(password),
            'role': 'user',
            'created_at': datetime.now().isoformat()
        }
        
        save_users(users)
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    settings = load_settings()
    return render_template('register.html', settings=settings)

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    username = session['username']
    users = load_users()
    vps_data = load_vps()
    settings = load_settings()
    
    user_vps = vps_data.get(username, [])
    
    total_ram = 0
    total_cpu = 0
    total_disk = 0
    active_count = 0
    
    for vps in user_vps:
        ram_gb = int(vps['ram'].replace('GB', ''))
        cpu_cores = int(vps['cpu'])
        disk_gb = int(vps['storage'].replace('GB', ''))
        
        total_ram += ram_gb
        total_cpu += cpu_cores
        total_disk += disk_gb
        
        if vps.get('status') == 'running' and not vps.get('suspended'):
            active_count += 1
    
    uptime = get_uptime()
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    return render_template('dashboard.html',
                         username=username,
                         role=users[username]['role'],
                         vps_list=user_vps,
                         total_ram=total_ram,
                         total_cpu=total_cpu,
                         total_disk=total_disk,
                         active_count=active_count,
                         uptime=uptime,
                         current_time=current_time,
                         settings=settings)

@app.route('/manage/<container_name>')
@login_required
def manage_vps(container_name):
    username = session['username']
    users = load_users()
    vps_data = load_vps()
    settings = load_settings()
    
    # Find VPS
    vps = None
    is_owner = False
    
    user_vps = vps_data.get(username, [])
    for v in user_vps:
        if v['container_name'] == container_name:
            vps = v
            is_owner = True
            break
    
    # Check if admin
    is_admin = users[username]['role'] == 'admin'
    
    if not vps and is_admin:
        # Admin can manage any VPS
        for user_id, vps_list in vps_data.items():
            for v in vps_list:
                if v['container_name'] == container_name:
                    vps = v
                    break
            if vps:
                break
    
    if not vps:
        flash('VPS not found', 'error')
        return redirect(url_for('dashboard'))
    
    # Get live stats
    status = get_container_status(container_name)
    cpu = get_container_cpu(container_name)
    memory = get_container_memory(container_name)
    disk = get_container_disk(container_name)
    
    return render_template('manage.html',
                         vps=vps,
                         status=status,
                         cpu=cpu,
                         memory=memory,
                         disk=disk,
                         is_owner=is_owner,
                         is_admin=is_admin,
                         settings=settings)

@app.route('/api/vps/action', methods=['POST'])
@login_required
def vps_action():
    data = request.get_json()
    action = data.get('action')
    container = data.get('container')
    
    username = session['username']
    users = load_users()
    vps_data = load_vps()
    
    # Check permissions
    is_admin = users[username]['role'] == 'admin'
    has_access = False
    
    user_vps = vps_data.get(username, [])
    for vps in user_vps:
        if vps['container_name'] == container:
            has_access = True
            break
    
    if not has_access and not is_admin:
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    try:
        if action == 'start':
            execute_lxc_sync(f'lxc start {container}')
            # Update status
            for user_id, vps_list in vps_data.items():
                for vps in vps_list:
                    if vps['container_name'] == container:
                        vps['status'] = 'running'
                        vps['suspended'] = False
            save_vps(vps_data)
            return jsonify({'success': True, 'message': 'VPS started successfully'})
        
        elif action == 'stop':
            execute_lxc_sync(f'lxc stop {container}')
            for user_id, vps_list in vps_data.items():
                for vps in vps_list:
                    if vps['container_name'] == container:
                        vps['status'] = 'stopped'
            save_vps(vps_data)
            return jsonify({'success': True, 'message': 'VPS stopped successfully'})
        
        elif action == 'restart':
            execute_lxc_sync(f'lxc restart {container}')
            return jsonify({'success': True, 'message': 'VPS restarted successfully'})
        
        elif action == 'stats':
            status = get_container_status(container)
            cpu = get_container_cpu(container)
            memory = get_container_memory(container)
            disk = get_container_disk(container)
            return jsonify({
                'success': True,
                'stats': {
                    'status': status,
                    'cpu': cpu,
                    'memory': memory,
                    'disk': disk
                }
            })
        
        elif action == 'ssh':
            # Generate tmate session
            session_name = f"svm-session-{int(time.time())}"
            execute_lxc_sync(f'lxc exec {container} -- tmate -S /tmp/{session_name}.sock new-session -d')
            time.sleep(3)
            
            result = subprocess.run(
                ['lxc', 'exec', container, '--', 'tmate', '-S', f'/tmp/{session_name}.sock', 'display', '-p', '#{tmate_ssh}'],
                capture_output=True, text=True
            )
            ssh_url = result.stdout.strip()
            
            return jsonify({'success': True, 'ssh_url': ssh_url})
        
        else:
            return jsonify({'success': False, 'message': 'Invalid action'}), 400
    
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    username = session['username']
    users = load_users()
    settings = load_settings()
    
    if request.method == 'POST':
        email = request.form.get('email')
        new_password = request.form.get('new_password')
        
        users[username]['email'] = email
        
        if new_password:
            users[username]['password'] = generate_password_hash(new_password)
        
        save_users(users)
        flash('Profile updated successfully', 'success')
        return redirect(url_for('profile'))
    
    return render_template('profile.html',
                         user=users[username],
                         settings=settings)

@app.route('/admin')
@admin_required
def admin_panel():
    users = load_users()
    vps_data = load_vps()
    settings = load_settings()
    
    total_users = len(users)
    total_vps = sum(len(vps_list) for vps_list in vps_data.values())
    
    total_ram = 0
    total_cpu = 0
    total_storage = 0
    running_vps = 0
    
    for vps_list in vps_data.values():
        for vps in vps_list:
            ram_gb = int(vps['ram'].replace('GB', ''))
            storage_gb = int(vps['storage'].replace('GB', ''))
            total_ram += ram_gb
            total_cpu += int(vps['cpu'])
            total_storage += storage_gb
            if vps.get('status') == 'running' and not vps.get('suspended'):
                running_vps += 1
    
    uptime = get_uptime()
    cpu_usage = get_cpu_usage()
    
    return render_template('admin.html',
                         total_users=total_users,
                         total_vps=total_vps,
                         total_ram=total_ram,
                         total_cpu=total_cpu,
                         total_storage=total_storage,
                         running_vps=running_vps,
                         uptime=uptime,
                         cpu_usage=cpu_usage,
                         settings=settings)

@app.route('/admin/users')
@admin_required
def admin_users():
    users = load_users()
    settings = load_settings()
    return render_template('admin_users.html', users=users, settings=settings)

@app.route('/admin/users/add', methods=['POST'])
@admin_required
def admin_add_user():
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')
    role = request.form.get('role')
    
    users = load_users()
    
    if username in users:
        flash('Username already exists', 'error')
        return redirect(url_for('admin_users'))
    
    users[username] = {
        'username': username,
        'email': email,
        'password': generate_password_hash(password),
        'role': role,
        'created_at': datetime.now().isoformat()
    }
    
    save_users(users)
    flash(f'User {username} added successfully', 'success')
    return redirect(url_for('admin_users'))

@app.route('/admin/users/delete/<username>', methods=['POST'])
@admin_required
def admin_delete_user(username):
    if username == 'admin':
        flash('Cannot delete admin account', 'error')
        return redirect(url_for('admin_users'))
    
    users = load_users()
    vps_data = load_vps()
    
    # Delete user's VPS
    if username in vps_data:
        for vps in vps_data[username]:
            try:
                execute_lxc_sync(f'lxc delete {vps["container_name"]} --force')
            except:
                pass
        del vps_data[username]
        save_vps(vps_data)
    
    # Delete user
    if username in users:
        del users[username]
        save_users(users)
    
    flash(f'User {username} deleted successfully', 'success')
    return redirect(url_for('admin_users'))

@app.route('/admin/vps')
@admin_required
def admin_vps():
    vps_data = load_vps()
    users = load_users()
    settings = load_settings()
    
    all_vps = []
    for user_id, vps_list in vps_data.items():
        for vps in vps_list:
            vps_info = vps.copy()
            vps_info['owner'] = user_id
            all_vps.append(vps_info)
    
    return render_template('admin_vps.html', vps_list=all_vps, settings=settings)

@app.route('/admin/vps/create', methods=['POST'])
@admin_required
def admin_create_vps():
    username = request.form.get('username')
    ram = int(request.form.get('ram'))
    cpu = int(request.form.get('cpu'))
    disk = int(request.form.get('disk'))
    
    users = load_users()
    vps_data = load_vps()
    
    if username not in users:
        flash('User not found', 'error')
        return redirect(url_for('admin_vps'))
    
    if username not in vps_data:
        vps_data[username] = []
    
    container_name = f"svm-vps-{username}-{int(time.time())}"
    ram_mb = ram * 1024
    
    try:
        execute_lxc_sync(f'lxc init ubuntu:22.04 {container_name} --storage {DEFAULT_STORAGE_POOL}')
        execute_lxc_sync(f'lxc config set {container_name} limits.memory {ram_mb}MB')
        execute_lxc_sync(f'lxc config set {container_name} limits.cpu {cpu}')
        execute_lxc_sync(f'lxc config device set {container_name} root size {disk}GB')
        execute_lxc_sync(f'lxc start {container_name}')
        
        vps_info = {
            'container_name': container_name,
            'ram': f'{ram}GB',
            'cpu': str(cpu),
            'storage': f'{disk}GB',
            'config': f'{ram}GB RAM / {cpu} CPU / {disk}GB Disk',
            'status': 'running',
            'suspended': False,
            'suspension_history': [],
            'created_at': datetime.now().isoformat(),
            'shared_with': []
        }
        
        vps_data[username].append(vps_info)
        save_vps(vps_data)
        
        flash(f'VPS created successfully for {username}', 'success')
    except Exception as e:
        flash(f'Failed to create VPS: {str(e)}', 'error')
    
    return redirect(url_for('admin_vps'))

@app.route('/admin/vps/delete/<container_name>', methods=['POST'])
@admin_required
def admin_delete_vps(container_name):
    vps_data = load_vps()
    
    try:
        execute_lxc_sync(f'lxc delete {container_name} --force')
        
        # Remove from database
        for user_id, vps_list in vps_data.items():
            vps_data[user_id] = [v for v in vps_list if v['container_name'] != container_name]
        
        save_vps(vps_data)
        flash(f'VPS {container_name} deleted successfully', 'success')
    except Exception as e:
        flash(f'Failed to delete VPS: {str(e)}', 'error')
    
    return redirect(url_for('admin_vps'))

@app.route('/admin/vps/suspend/<container_name>', methods=['POST'])
@admin_required
def admin_suspend_vps(container_name):
    vps_data = load_vps()
    
    try:
        execute_lxc_sync(f'lxc stop {container_name}')
        
        for user_id, vps_list in vps_data.items():
            for vps in vps_list:
                if vps['container_name'] == container_name:
                    vps['status'] = 'suspended'
                    vps['suspended'] = True
                    if 'suspension_history' not in vps:
                        vps['suspension_history'] = []
                    vps['suspension_history'].append({
                        'time': datetime.now().isoformat(),
                        'reason': 'Admin action',
                        'by': session['username']
                    })
        
        save_vps(vps_data)
        flash(f'VPS {container_name} suspended successfully', 'success')
    except Exception as e:
        flash(f'Failed to suspend VPS: {str(e)}', 'error')
    
    return redirect(url_for('admin_vps'))

@app.route('/admin/vps/unsuspend/<container_name>', methods=['POST'])
@admin_required
def admin_unsuspend_vps(container_name):
    vps_data = load_vps()
    
    try:
        execute_lxc_sync(f'lxc start {container_name}')
        
        for user_id, vps_list in vps_data.items():
            for vps in vps_list:
                if vps['container_name'] == container_name:
                    vps['status'] = 'running'
                    vps['suspended'] = False
        
        save_vps(vps_data)
        flash(f'VPS {container_name} unsuspended successfully', 'success')
    except Exception as e:
        flash(f'Failed to unsuspend VPS: {str(e)}', 'error')
    
    return redirect(url_for('admin_vps'))

@app.route('/admin/settings', methods=['GET', 'POST'])
@admin_required
def admin_settings():
    settings = load_settings()
    
    if request.method == 'POST':
        settings['panel_name'] = request.form.get('panel_name')
        settings['announcement'] = request.form.get('announcement')
        settings['background_image'] = request.form.get('background_image')
        
        save_settings(settings)
        flash('Settings updated successfully', 'success')
        return redirect(url_for('admin_settings'))
    
    return render_template('admin_settings.html', settings=settings)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)
