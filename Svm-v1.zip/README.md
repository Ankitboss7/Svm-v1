# SVM Panel - Virtual Machine Management System

A modern web-based VPS management panel powered by LXC/LXD.

## Features

### For Users
- **Dashboard**: View all your VPS instances at a glance
- **VPS Management**: Start, stop, restart VPS with one click
- **SSH Access**: Generate instant SSH access using tmate
- **Live Statistics**: Monitor CPU, RAM, and disk usage in real-time
- **Profile Management**: Update your account details

### For Administrators
- **User Management**: Create, delete, and manage user accounts
- **VPS Creation**: Deploy new VPS instances with custom resources
- **Resource Allocation**: Assign RAM, CPU, and disk space
- **Suspend/Unsuspend**: Control VPS access and status
- **System Monitoring**: View overall system resource usage
- **Panel Customization**: Configure panel name, announcements, and theme

### Security Features
- **Auto CPU Monitoring**: Automatically stops all VPS if CPU usage exceeds threshold
- **Resource Limits**: Enforce CPU and RAM limits per VPS
- **Role-Based Access**: Admin and User roles with different permissions
- **Suspension System**: Track and manage VPS suspensions

## Installation

### Prerequisites
- Ubuntu 22.04 LTS (recommended)
- Root access
- At least 4GB RAM
- 20GB free disk space

### Quick Install

1. **Clone or download the project**
```bash
cd /opt
git clone <repository-url> svm-panel
cd svm-panel
```

2. **Run the installation script**
```bash
chmod +x install.sh
sudo ./install.sh
```

3. **Start the panel**
```bash
source venv/bin/activate
python3 app.py
```

4. **Access the panel**
Open your browser and navigate to:
```
http://your-server-ip:3000
```

### Default Credentials
- **Username**: admin
- **Password**: admin

⚠️ **IMPORTANT**: Change the default admin password immediately after first login!

## Manual Installation

If you prefer manual installation:

```bash
# 1. Update system
sudo apt update && sudo apt upgrade -y

# 2. Install LXC/LXD
sudo apt install lxc lxc-utils -y
sudo apt install snapd -y
sudo systemctl enable --now snapd.socket
sudo snap install lxd

# 3. Add user to lxd group
sudo usermod -aG lxd $USER
newgrp lxd

# 4. Initialize LXD
sudo lxd init
# Press ENTER to accept defaults

# 5. Install Python dependencies
sudo apt install python3 python3-pip python3-venv -y

# 6. Create virtual environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 7. Start the application
python3 app.py
```

## Configuration

### Application Settings
Edit `app.py` to configure:
- `DEFAULT_STORAGE_POOL`: LXD storage pool name
- `CPU_THRESHOLD`: CPU usage limit before auto-shutdown (default: 90%)
- `RAM_THRESHOLD`: RAM usage limit before auto-shutdown (default: 90%)
- `CHECK_INTERVAL`: Monitoring interval in seconds (default: 600)

### LXD Configuration
To check or modify LXD configuration:
```bash
lxc storage list
lxc network list
lxc profile list
```

## Usage

### Creating a User Account
1. Navigate to Admin Panel → Manage Users
2. Fill in the user details
3. Select role (User or Admin)
4. Click "Add User"

### Creating a VPS
1. Go to Admin Panel → Manage VPS
2. Enter username, RAM (GB), CPU (cores), and Disk (GB)
3. Click "Create VPS"
4. VPS will be created with Ubuntu 22.04 LTS

### Accessing VPS via SSH
1. Go to Dashboard → Click "Manage" on your VPS
2. Click "SSH Access" button
3. Copy the generated tmate command
4. Paste in your terminal to connect

## Troubleshooting

### LXC Commands Not Working
```bash
# Check if you're in lxd group
groups

# If not, add yourself
sudo usermod -aG lxd $USER
newgrp lxd
```

### VPS Won't Start
```bash
# Check LXD status
sudo systemctl status snap.lxd.daemon

# Check container logs
lxc info <container-name>
```

### Port 3000 Already in Use
Edit `app.py` and change the port:
```python
app.run(host='0.0.0.0', port=5000, debug=True)
```

### Permission Denied Errors
```bash
# Ensure proper permissions
sudo chown -R $USER:$USER /opt/svm-panel
```

## System Commands

### Via Panel
All commands are available through the web interface for admin users.

### Via CLI (Advanced)
```bash
# List all containers
lxc list

# Start a container
lxc start <container-name>

# Stop a container
lxc stop <container-name>

# Delete a container
lxc delete <container-name> --force

# Execute command in container
lxc exec <container-name> -- <command>
```

## File Structure
```
svm-panel/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── install.sh            # Installation script
├── README.md             # This file
├── templates/            # HTML templates
│   ├── base.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── manage.html
│   ├── profile.html
│   ├── admin.html
│   ├── admin_users.html
│   ├── admin_vps.html
│   └── admin_settings.html
├── static/               # Static files
│   └── css/
│       └── style.css
└── data files/           # Auto-generated
    ├── users.json
    ├── vps_data.json
    └── settings.json
```

## API Endpoints

### VPS Actions
**POST** `/api/vps/action`
```json
{
  "action": "start|stop|restart|stats|ssh",
  "container": "container-name"
}
```

## Security Recommendations

1. **Change Default Credentials** immediately after installation
2. **Use Firewall**: Configure UFW to allow only necessary ports
   ```bash
   sudo ufw allow 3000
   sudo ufw enable
   ```
3. **SSL/TLS**: Use a reverse proxy (nginx) with SSL certificates
4. **Regular Updates**: Keep system and panel updated
5. **Backup Data**: Regularly backup `users.json` and `vps_data.json`
6. **Strong Passwords**: Enforce strong password policies

## Production Deployment

For production use, consider:

1. **Use Gunicorn or uWSGI** instead of Flask development server
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:3000 app:app
```

2. **Setup Nginx** as reverse proxy
3. **Enable SSL** with Let's Encrypt
4. **Create systemd service** for auto-start
5. **Setup monitoring** with systemd or supervisord

## License

This project is licensed under the MIT License.

## Support

For issues and feature requests, please contact the administrator.

## Credits

Developed for SVM Panel - Virtual Machine Management System
Powered by Flask, LXC/LXD, and Python
